﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CompraWithDB.Models
{
    public class Compra : DbContext
    {
        public Compra(DbContextOptions<Compra> options)
            : base(options)
        { }

        public DbSet<Pagado> Pagados { get; set; }
        public DbSet<Post> Posts { get; set; }
    }

    public class Pagado
    {
        [Key]
        public int ProductId { get; set; }
        //public string Url { get; set; }

        public ICollection<Post> Posts { get; set; }
    }

    public class Post
    {
        public int PostId { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }

        public int ProductId { get; set; }
        public Pagado Pagado { get; set; }
    }
}