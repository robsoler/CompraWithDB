﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CompraWithDB.Models;

namespace CompraWithDB.Controllers
{
    public class PagadosController : Controller
    {
        private readonly Compra _context;

        public PagadosController(Compra context)
        {
            _context = context;
        }

        // GET: Pagados
        public async Task<IActionResult> Index()
        {
            return View(await _context.Pagados.ToListAsync());
        }

        // GET: Pagados/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pagado = await _context.Pagados
                .FirstOrDefaultAsync(m => m.ProductId == id);
            if (pagado == null)
            {
                return NotFound();
            }

            return View(pagado);
        }

        // GET: Pagados/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Pagados/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ProductId")] Pagado pagado)
        {
            if (ModelState.IsValid)
            {
                _context.Add(pagado);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(pagado);
        }

        // GET: Pagados/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pagado = await _context.Pagados.FindAsync(id);
            if (pagado == null)
            {
                return NotFound();
            }
            return View(pagado);
        }

        // POST: Pagados/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ProductId")] Pagado pagado)
        {
            if (id != pagado.ProductId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(pagado);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PagadoExists(pagado.ProductId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(pagado);
        }

        // GET: Pagados/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pagado = await _context.Pagados
                .FirstOrDefaultAsync(m => m.ProductId == id);
            if (pagado == null)
            {
                return NotFound();
            }

            return View(pagado);
        }

        // POST: Pagados/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var pagado = await _context.Pagados.FindAsync(id);
            _context.Pagados.Remove(pagado);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PagadoExists(int id)
        {
            return _context.Pagados.Any(e => e.ProductId == id);
        }
    }
}
